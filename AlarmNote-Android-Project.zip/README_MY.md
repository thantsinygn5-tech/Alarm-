# Alarm Note (Android)

ဒီ Project သည် Android Studio ဖြင့် APK ထုတ်ရန် ရေးထားသော Kotlin project ဖြစ်သည်။

## APK ထုတ်နည်း
1. ကွန်ပျူတာတွင် Android Studio ကို install လုပ်ပါ။
2. Android Studio > Open ကိုနှိပ်ပြီး `AlarmNote` folder ကိုရွေးပါ။
3. Gradle Sync ပြီးအောင်စောင့်ပါ။
4. ဖုန်းကို USB ဖြင့်ချိတ်ပါ (သို့) Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
5. `app/build/outputs/apk/debug/app-debug.apk` ကို ဖုန်းထဲထည့်ပြီး install လုပ်ပါ။

## လုပ်ဆောင်ချက်
- အချိန်ရွေးပြီး Alarm သတ်မှတ်နိုင်သည်။
- နေ့တိုင်း ထပ်မြည်ရန် ရွေးနိုင်သည်။
- Alarm မြည်ချိန်တွင် စာလုံး ၁ လုံးအပါအဝင် မည်သည့်စာမဆို ရေးပြီးမှ ပိတ်နိုင်သည်။
- မှတ်စုများကို Main screen တွင် ပြန်ကြည့်နိုင်သည်။

မှတ်ချက်: Android ဗားရှင်း/ဖုန်းထုတ်လုပ်သူအလိုက် exact alarm နှင့် notification ခွင့်ပြုချက်များ တောင်းနိုင်သည်။ Xiaomi ဖုန်းများတွင် Battery saver ကန့်သတ်ချက်များကြောင့် Alarm မလွတ်စေရန် Autostart နှင့် background permission ကိုလည်း ခွင့်ပြုပါ။
