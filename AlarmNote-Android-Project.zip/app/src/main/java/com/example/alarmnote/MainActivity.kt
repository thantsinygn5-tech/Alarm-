package com.example.alarmnote

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("alarm", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Alarm Note"
            textSize = 28f
        })
        layout.addView(TextView(this).apply {
            text = "Alarm မြည်လာရင် စာတစ်လုံးရေးပြီး ပိတ်နိုင်ပါတယ်။"
            textSize = 16f
        })
        val picker = TimePicker(this).apply { setIs24HourView(true) }
        layout.addView(picker)
        val repeat = CheckBox(this).apply {
            text = "နေ့တိုင်း ထပ်မြည်မယ်"
            isChecked = prefs.getBoolean("repeat", false)
        }
        layout.addView(repeat)
        val button = Button(this).apply { text = "Alarm သတ်မှတ်မယ်" }
        layout.addView(button)
        val status = TextView(this).apply { textSize = 16f }
        layout.addView(status)
        val historyTitle = TextView(this).apply {
            text = "မှတ်တမ်း"
            textSize = 20f
        }
        layout.addView(historyTitle)
        val history = TextView(this).apply {
            text = prefs.getString("history", "မှတ်တမ်း မရှိသေးပါ") ?: ""
            textSize = 16f
        }
        layout.addView(history)
        setContentView(ScrollView(this).apply { addView(layout) })

        button.setOnClickListener {
            if (android.os.Build.VERSION.SDK_INT >= 31 &&
                !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                Toast.makeText(this, "Alarm ခွင့်ပြုချက်ပေးပြီး ပြန်သတ်မှတ်ပါ", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val hour = picker.hour
            val minute = picker.minute
            prefs.edit().putInt("hour", hour).putInt("minute", minute)
                .putBoolean("repeat", repeat.isChecked).apply()
            schedule(hour, minute)
            status.text = "သတ်မှတ်ပြီးပါပြီ — %02d:%02d".format(hour, minute)
            Toast.makeText(this, "Alarm သတ်မှတ်ပြီးပါပြီ", Toast.LENGTH_SHORT).show()
        }
    }

    private fun schedule(hour: Int, minute: Int) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 10, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAlarmClock(AlarmManager.AlarmClockInfo(c.timeInMillis, pi), pi)
    }
}
