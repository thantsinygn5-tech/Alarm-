package com.example.alarmnote

import android.app.Activity
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.*

class AlarmRingActivity : Activity() {
    private var ringtone: Ringtone? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        ringtone = RingtoneManager.getRingtone(this,
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        ringtone?.play()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
        }
        box.addView(TextView(this).apply {
            text = "⏰ Alarm မြည်နေပါပြီ!"
            textSize = 28f
        })
        box.addView(TextView(this).apply {
            text = "ပိတ်ရန် မှတ်စုတစ်ခုခု ရေးပါ (စာလုံး ၁ လုံးလည်း ရပါတယ်)"
            textSize = 17f
        })
        val input = EditText(this).apply {
            hint = "မှတ်စုရေးပါ..."
            minLines = 2
        }
        box.addView(input)
        val dismiss = Button(this).apply { text = "မှတ်စုရေးပြီး Alarm ပိတ်မယ်" }
        box.addView(dismiss)
        setContentView(box)
        dismiss.setOnClickListener {
            val note = input.text.toString().trim()
            if (note.isEmpty()) {
                Toast.makeText(this, "စာတစ်လုံးလောက် ရေးပေးပါ", Toast.LENGTH_SHORT).show()
            } else {
                val p = getSharedPreferences("alarm", MODE_PRIVATE)
                val old = p.getString("history", "") ?: ""
                val entry = "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())} — $note"
                p.edit().putString("history", (entry + "\n" + old).take(5000)).apply()
                ringtone?.stop()
                finish()
            }
        }
    }
    override fun onDestroy() {
        ringtone?.stop()
        super.onDestroy()
    }
}
