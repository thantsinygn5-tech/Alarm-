package com.example.alarmnote

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.media.Ringtone
import android.media.RingtoneManager
import android.widget.*
import android.view.WindowManager

class RingActivity : Activity() {
    private var ringtone: Ringtone? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        ringtone?.play()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 60, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "Alarm မြည်နေပါတယ်။\nပိတ်ရန် စာတစ်ခုခုရေးပါ။"
            textSize = 24f
        })
        val note = EditText(this).apply {
            hint = "စာတစ်လုံးပဲ ရေးလည်းရပါတယ်"
            minLines = 2
        }
        layout.addView(note)
        val stop = Button(this).apply { text = "ရေးပြီး Alarm ပိတ်မည်" }
        layout.addView(stop)
        stop.setOnClickListener {
            if (note.text.toString().trim().isEmpty()) {
                Toast.makeText(this, "စာတစ်လုံးလောက် ရေးပါ", Toast.LENGTH_SHORT).show()
            } else {
                getSharedPreferences("notes", Context.MODE_PRIVATE).edit()
                    .putString("last_note", note.text.toString()).apply()
                ringtone?.stop()
                finish()
            }
        }
        setContentView(layout)
    }
    override fun onDestroy() {
        ringtone?.stop()
        super.onDestroy()
    }
}
