package com.example.alarmnote

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Alarm Note"
            textSize = 28f
        })
        layout.addView(TextView(this).apply {
            text = "Alarm မြည်လာရင် စာတစ်လုံးပဲဖြစ်ဖြစ် ရေးပြီးမှ ပိတ်နိုင်ပါတယ်။"
            textSize = 16f
        })
        val picker = TimePicker(this).apply { setIs24HourView(true) }
        layout.addView(picker)
        val repeat = CheckBox(this).apply { text = "နေ့တိုင်း ထပ်မြည်ရန်" }
        layout.addView(repeat)
        val set = Button(this).apply { text = "Alarm သတ်မှတ်မည်" }
        layout.addView(set)
        set.setOnClickListener {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, picker.hour)
                set(Calendar.MINUTE, picker.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val pi = PendingIntent.getBroadcast(
                this, 100,
                Intent(this, AlarmReceiver::class.java).putExtra("repeat", repeat.isChecked),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, null), pi)
                Toast.makeText(this, "Alarm သတ်မှတ်ပြီးပါပြီ", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Alarm မသတ်မှတ်နိုင်ပါ: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        setContentView(layout)
    }
}
